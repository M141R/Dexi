import os
openweather = os.environ['OPENWEATHER']
token = os.environ['TOKEN']

TOKEN = token
PREFIX = '!'
OPENWEATHER = openweather