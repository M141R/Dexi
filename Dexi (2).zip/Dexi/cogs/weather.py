import discord
import os
from discord.ext import commands
import requests
from config import OPENWEATHER 

 # get it from https://openweathermap.org/api

class Weather(commands.Cog):
    def __init__(self,bot):
      self.bot = bot
  
    @commands.command()
    async def weather(self, ctx, *, location : str=None):
      API_ID = OPENWEATHER
      if location == None:
          ctx.command.reset_cooldown(ctx)
          await ctx.send('You havent provided a location!')
      else:
          try:
              x = location.lower()
              x = requests.get('http://api.openweathermap.org/data/2.5/weather?q={}&APPID={}'.format(x, API_ID)).json()
              country, city = x['sys']['country'], x['name']
              cord1, cord2 = x['coord']['lon'], x['coord']['lat']
              main, desc = x['weather'][0]['main'], x['weather'][0]['description']
              speed, humid = x['wind']['speed'], x['main']['humidity']
              icon, pressure, clouds = x['weather'][0]['icon'], x['main']['pressure'], x['clouds']['all']
              temp, temp_f, zone = x['main']['temp'], x['main']['feels_like'], x['timezone']
              embed=discord.Embed(
                  title=f'{city} ({country})',
                  colour=discord.Color.blue(),
                  description=f'Longitude : {cord1} | Latitude : {cord2}'
              )
              embed.set_thumbnail(url=f"https://openweathermap.org/img/w/{icon}.png")
              embed.add_field(name='Wind', value=f'{speed} MPH')
              embed.add_field(name='Humidity', value=f'{humid}%')
              embed.add_field(name='Weather', value=f'{main} ({desc})')
              embed.add_field(name='Pressure', value=f'{pressure}')
              embed.add_field(name='Clouds', value=f'{clouds}')
              embed.add_field(name='Temperature', value=f'{round(temp - 273.15)} °C')
              embed.add_field(name='Feels Like', value=f'{round(temp_f - 273.15)} °C')
              embed.add_field(name=f'Time Zone', value=f'{zone}')
              embed.add_field(name=f'Min Temp', value=str(round(x['main']['temp_min'] - 273.15)) + ' °C')
              embed.add_field(name=f'Max Temp', value=str(round(x['main']['temp_max'] - 273.15)) + ' °C')
              await ctx.send(embed=embed)
          except KeyError:
              await ctx.send('Location was invalid.')


async def setup(bot):
  await bot.add_cog(Weather(bot))