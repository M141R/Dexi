import discord
from typing import Optional,Union
from discord.ext import commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def info(self, ctx):
        """Displays bot information."""
        embed = discord.Embed(title="Bot Information", color=0x00ff00)
        embed.add_field(name="Bot Name", value=self.bot.user.name, inline=False)
        embed.add_field(name="Bot ID", value=self.bot.user.id, inline=False)
        await ctx.send(embed=embed)

    @commands.command()
    async def serverinfo(self, ctx):
        """Displays server information."""
        guild = ctx.guild
        embed = discord.Embed(title=f"{guild.name} Information", color=0x00ff00)
        embed.add_field(name="Server Name", value=guild.name, inline=False)
        embed.add_field(name="Server ID", value=guild.id, inline=False)
        embed.add_field(name="Server Owner", value=guild.owner, inline=False)
        embed.add_field(name="Server Members", value=guild.member_count, inline=False)
        await ctx.send(embed=embed)

    @commands.command()
    async def userinfo(self, ctx, *, user: discord.Member = None):
        """Displays user information."""
        user = user or ctx.author
        embed = discord.Embed(title=f"{user.name} Information", color=0x00ff00)
        embed.set_thumbnail(url=user.avatar)
        embed.add_field(name="User Name", value=user.name, inline=False)
        embed.add_field(name="User ID", value=user.id, inline=False)
        embed.add_field(name="User Status", value=str(user.status).title(), inline=False)
        embed.add_field(name="User Joined", value=user.joined_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
        embed.add_field(name="User Created", value=user.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
        await ctx.send(embed=embed)

    @commands.command()
    async def avatar(self, ctx, member: Union[discord.Member, discord.User] = None):
        """Displays a user's avatar."""
        user = member or ctx.author
        if isinstance(user, discord.Member):
            user = ctx.guild.get_member(user.id)
        embed = discord.Embed(title=f"{user.name}'s Avatar", color=0x00ff00)
        embed.set_image(url=user.avatar)
        await ctx.send(embed=embed)

    @commands.command()
    async def poll(self, ctx, question, *options):
        """Creates a poll with given question and options."""
        if len(options) <= 1:
            await ctx.send("You need to provide at least 2 options.")
            return
        if len(options) > 10:
            await ctx.send("You can provide at most 10 options.")
            return
        reactions = ["🇦", "🇧", "🇨", "🇩", "🇪", "🇫", "🇬", "🇭", "🇮", "🇯"][:len(options)]
        embed = discord.Embed(title=question, color=0x00ff00)
        for i, option in enumerate(options):
            embed.add_field(name=f"{reactions[i]} {option}", value="\u200b", inline=False)
        message = await ctx.send(embed=embed)
        for reaction in reactions:
            await message.add_reaction(reaction)
    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def setprefix(self, ctx, prefix: str):
        """Sets the bot's command prefix for this server."""
        self.bot.command_prefix = prefix
        await ctx.send(f"The command prefix has been set to '{prefix}'.")

async def setup(bot):
    await bot.add_cog(Utility(bot))