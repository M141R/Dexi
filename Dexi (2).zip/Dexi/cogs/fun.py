import random
import requests
import discord
from discord.ext import commands
from discord import app_commands

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name='roll',description='Rolls a dice')
    async def roll(self,interaction: discord.Interaction):
        result = random.randint(1, 6)
        await interaction.response.send_message(f"🎲 You rolled a {result}.")

    @commands.command()
    async def flip(self, ctx):
        """Flips a coin."""
        result = random.choice(["heads", "tails"])
        await ctx.send(f"🪙 The coin landed on {result}.")

    @commands.command()
    async def choose(self, ctx, *options):
        """Chooses one option from a list of options."""
        if len(options) < 2:
            await ctx.send("Please provide at least two options.")
            return
        choice = random.choice(options)
        await ctx.send(f"I choose {choice}.")

    @commands.command()
    async def trivia(self, ctx):
        """Asks a trivia question."""
        response = requests.get("https://opentdb.com/api.php?amount=1&type=multiple")
        if response.status_code == 200:
            data = response.json()
            question = data["results"][0]["question"]
            choices = data["results"][0]["incorrect_answers"]
            correct_choice = data["results"][0]["correct_answer"]
            choices.append(correct_choice)
            random.shuffle(choices)
            choices_text = "\n".join(f"{i + 1}. {choice}" for i, choice in enumerate(choices))
            embed = discord.Embed(title="Trivia Question", description=question, color=discord.Color.blue())
            embed.add_field(name="Choices", value=choices_text, inline=False)
            embed.add_field(name="Correct Choice", value=f"||{correct_choice}||")
            await ctx.send(embed=embed)
        else:
            await ctx.send("An error occurred while fetching the trivia question.")

    @commands.command()
    async def joke(self, ctx):
        """Tells a joke."""
        response = requests.get("https://official-joke-api.appspot.com/random_joke")
        if response.status_code == 200:
            data = response.json()
            setup = data["setup"]
            punchline = data["punchline"]
            embed = discord.Embed(title="Joke", description=f"{setup}\n\n||{punchline}||", color=discord.Color.orange())
            await ctx.send(embed=embed)
        else:
            await ctx.send("An error occurred while fetching the joke.")

async def setup(bot):
    await bot.add_cog(Fun(bot))
