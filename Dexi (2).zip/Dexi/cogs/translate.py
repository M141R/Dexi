import discord
from discord.ext import commands
from googletrans import Translator

class Translate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.translator = Translator()

    @commands.command()
    async def translate(self, ctx, src_lang, tgt_lang, *, text):
      """Translates the given text from the source language to the target language."""
      try:
          # Translate the text
          translation = self.translator.translate(text, src=src_lang, dest=tgt_lang)
  
          # Send the translated message
          await ctx.send(f'{ctx.author.mention} said "{text}" in {src_lang}:\n\n{translation.text} ({tgt_lang})')
      except AttributeError:
          # Send an error message if the translation failed
          await ctx.send(f'Sorry, I was unable to translate "{text}" from {src_lang} to {tgt_lang}. Please try again later.')

async def setup(bot):
    await bot.add_cog(Translate(bot))
