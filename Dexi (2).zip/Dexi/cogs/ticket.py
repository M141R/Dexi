import discord
import asyncio
from discord.ext import commands

class Ticket(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ticket_category_id = None
        self.ticket_counter = 0
      
    # Command for setting up the ticket category
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def setcategory(self, ctx, category_id: int):
        """
        Sets the category ID for tickets.
        """
        category = self.bot.get_channel(category_id)
        if not category:
            return await ctx.send("Invalid category ID.")
        self.category_id = category_id
        await ctx.send(f"Ticket category set to {category.name}.")

    @commands.command()
    async def ticket(self, ctx):
        """
        Creates a new ticket in the set category.
        """
        if not self.category_id:
            return await ctx.send("Ticket category has not been set. Use the setcategory command first.")
        category = self.bot.get_channel(self.category_id)
        ticket_name = f"ticket-{ctx.author.display_name}"
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            ctx.author: discord.PermissionOverwrite(read_messages=True, send_messages=True),
        }
        ticket = await category.create_text_channel(name=ticket_name, overwrites=overwrites)
        await ctx.send(f"Ticket created: {ticket.mention}")
        await ticket.send("React with \U0001F6AB to close this ticket.")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) == "\U0001F6AB" and reaction.message.id == ticket.id

        try:
            reaction, _ = await self.bot.wait_for("reaction_add", check=check, timeout=86400)
        except asyncio.TimeoutError:
            pass
        else:
            await ticket.delete()

    @commands.command()
    async def close(self, ctx):
        """
        Closes the user's own ticket.
        """
        ticket = ctx.channel
        if not ticket.name.startswith("ticket-") or ticket.category_id != self.category_id:
            return await ctx.send("This command can only be used in a ticket channel.")
        await ticket.delete()



async def setup(bot):
    await bot.add_cog(Ticket(bot))
