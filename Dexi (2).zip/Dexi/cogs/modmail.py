import discord
from discord.ext import commands

class ModMail(commands.Cog):
    """Mod mail-related commands"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def modmail(self, ctx, *, message):
        """Sends a message to the server's moderators"""
        embed = discord.Embed(title="New mod mail message", description=message, color=discord.Color.blue())

        for guild in self.bot.guilds:
            if guild.name == "Test":  # Replace with your server's name
                # Find the role named "Moderators" and send the message to all members with that role
                role = discord.utils.get(guild.roles, name="Moderators")
                if role:
                    for member in role.members:
                        try:
                            await member.send(embed=embed)
                        except discord.Forbidden:
                            pass

        await ctx.send("Your mod mail message has been sent to the moderators.")

    @modmail.error
    async def modmail_error(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("Please provide your message.")

async def setup(bot):
    await bot.add_cog(ModMail(bot))
