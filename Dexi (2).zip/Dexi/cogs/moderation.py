import discord
from discord.ext import commands

class Moderation(commands.Cog):
    """Moderation-related commands"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        """Kicks a member from the server"""
        await member.kick(reason=reason)
        await ctx.send(f"{member.mention} has been kicked.")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
        """Bans a member from the server"""
        await member.ban(reason=reason)
        await ctx.send(f"{member.mention} has been banned.")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, *, member):
        """Unbans a member from the server"""
        banned_users = await ctx.guild.bans()
        member_name, member_discriminator = member.split("#")

        for banned_entry in banned_users:
            user = banned_entry.user

            if (user.name, user.discriminator) == (member_name, member_discriminator):
                await ctx.guild.unban(user)
                await ctx.send(f"{user.mention} has been unbanned.")
                return

        await ctx.send(f"{member} was not found in the ban list.")

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def mute(self, ctx, member: discord.Member, *, reason=None):
        """Mutes a member in the server"""
        role = discord.utils.get(ctx.guild.roles, name="Muted")

        if not role:
            # Create a new role called "Muted" if it doesn't exist
            role = await ctx.guild.create_role(name="Muted")

            # Set the permissions for the "Muted" role
            for channel in ctx.guild.channels:
                await channel.set_permissions(role, send_messages=False)

        # Add the "Muted" role to the specified member
        await member.add_roles(role, reason=reason)
        await ctx.send(f"{member.mention} has been muted.")

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def unmute(self, ctx, member: discord.Member):
        """Unmutes a member in the server"""
        role = discord.utils.get(ctx.guild.roles, name="Muted")

        if role in member.roles:
            # Remove the "Muted" role from the specified member
            await member.remove_roles(role)
            await ctx.send(f"{member.mention} has been unmuted.")
        else:
            await ctx.send(f"{member.mention} is not muted.")

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, limit: int):
        """Deletes a specified number of messages from the channel"""
        await ctx.channel.purge(limit=limit+1)
        await ctx.send(f"{limit} messages have been purged.")

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def addrole(self, ctx, member: discord.Member, role: discord.Role):
        """Adds a role to a member."""
        await member.add_roles(role)
        await ctx.send(f"{role.name} has been added to {member.display_name}.")

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def removerole(self, ctx, member: discord.Member, role: discord.Role):
        """Removes a role from a member."""
        await member.remove_roles(role)
        await ctx.send(f"{role.name} has been removed from {member.display_name}.")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
